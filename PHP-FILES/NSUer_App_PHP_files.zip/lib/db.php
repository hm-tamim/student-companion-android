<?php
/* MySQL Database Configuration*/
$db_host='127.0.0.1';
$db_user='user';
$db_pass='pass';
$db_name='dp_name';
?>